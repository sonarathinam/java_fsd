package email;
import java.util.ArrayList;
import java.util.Scanner;
public class Emailvalidation {

public static void valid(ArrayList<String>list)
{
System.out.println("Enter the Email ID: ");
Scanner input = new Scanner(System.in);
     String sc=input.next();
     int count=0;
for(String element:list)
{
     if(element.equals(sc))
     {
     count=1;
     break;
     }
     }
if(count==1)
{
System.out.println("Great!Your EMail ID is valid");
}
else
{
System.out.println("Sorry,Your EmailID is not valid");
}
}
public static void main(String[] args)
{
ArrayList <String> list=new ArrayList<String>();
 for(int i=0;i<100;i++)
 {
 list.add("email"+i+"@gmail.com");
 }
Emailvalidation.valid(list);
   
   
}
}





