package Hashmap;
import java.util.*;


public class EFG {

 
 public static void main(String[] args)
 {

     Map<String, Integer> map = new LinkedHashMap<>();

     
     map.put("ROSE", 10);
     map.put("JACKY", 30);
     map.put("RITA", 20);

    
     for (Map.Entry<String, Integer> e : map.entrySet())

         
         System.out.println(e.getKey() + " "
                            + e.getValue());
 }
}

	

