package Assitedinnerclass;

public class Red {
	private String msg="Welcoming java programming"; 
	 
	 class Inner{  
	  void hello(){System.out.println(msg+", learn java program");}  
	 }  


	public static void main(String[] args) {

		Red obj=new Red();
		Red.Inner in=obj.new Inner();  
		in.hello();  
	}
}



