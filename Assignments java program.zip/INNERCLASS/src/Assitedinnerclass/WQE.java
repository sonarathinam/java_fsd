package Assitedinnerclass;
import java.lang.reflect.Modifier;

public class WQE {
	public static void main(String[] args)
    {
 
        // Creating a local inner class object
		WQE wqe = new WQE() {
 
        };
 
        // getClass() method of an object returns a
        // java.lang.CLass
        // instance representing the class of the object
        Class classInstance = wqe.getClass();
 
        // Checking whether Class is -
        // local, member, an anonymous inner class
        // and not static
        boolean isInnerClass = (classInstance.isMemberClass() || classInstance.isLocalClass()  || classInstance.isAnonymousClass()) && !Modifier.isStatic(
                     classInstance.getModifiers());
 
        // Printing the results
        System.out.println(
            "Is wqe an inner class object? : "
            + isInnerClass);
    }
}


	  


	 