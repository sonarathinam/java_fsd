
public class methods {

	public static void main(String[] args) {
		welcome();
		multiply(5,10);
		multiply(3,12);
		multiply(6,8);
		addition(2,4);
		addition(4,6);
		addition(8,9);
		
		

	}
	public static void welcome() {
		System.out.println("welcome to our claculator");
	}
	
	public static void multiply(int a, int b) {
		System.out.println(a*b);

}
	public static void addition(int a, int b) {
		System.out.println(a+b);
}
}