package Specifers;

public class ACCESSMODIFIERS2 {
	public static void main(String [] args) {

		ACCESSMODIFIERS obj= new  ACCESSMODIFIERS();

		obj.methodDefault();
		obj.methodProtected();
		obj.methodPublic();
	}
}


