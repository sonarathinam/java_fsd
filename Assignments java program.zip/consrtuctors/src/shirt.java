
public class shirt {
	public static String color;
	public static char size;
	shirt() {
		System.out.println("inside construction!");
	}
	public static void putOn() {
		System.out.println("Shirt is on!");
		
	}
	public static void takeoff() {
		System.out.println("shirt is off!");
	}
	public static void setcolor(String newcolor) {
		color=newcolor;
		
	}
	public static void setsize(char newsize) {
		size=newsize;
		

}
}
